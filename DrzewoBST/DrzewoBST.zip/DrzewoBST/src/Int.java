public class Int implements Porownywacz<Integer> {

    public int porownaj(Integer a, Integer b) { return a.compareTo(b); }
}