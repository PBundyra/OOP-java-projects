public interface Porownywacz<T> {
    int porownaj(T a, T b);
}